/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package donnees;

/**
 *
 * @author marce
 */
public class Personne {
    public String   prenom;
    public int      niveau;
    public long     score;
    
    public void afficher(){
        System.out.print("Pseudo:                   Niveau maximum:                            Score:");
        System.out.printf("%-15s %-15d %15L", prenom, niveau, score);
    }
}
