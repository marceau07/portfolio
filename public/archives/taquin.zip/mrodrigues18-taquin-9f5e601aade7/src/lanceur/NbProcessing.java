package lanceur;

import lecode.Sketch;


public class NbProcessing {

    public static void main(String[] args){
           
       String[] param={"lecode.Sketch"};
       Sketch.main(param);
        
    }
}
